# TextFLIX

Interface simples inspirada na Netflix, desenvolvida apenas com **HTML e CSS**.

## Instruções

1. Baixe e extraia o arquivo `.zip`.
2. Abra o arquivo `index.html` em qualquer navegador (duplo clique).
3. Visualize a interface simulando um aplicativo de streaming.

---
**Arquivos incluídos:**
- `index.html` — código da interface.
- `README.md` — instruções diretas para o avaliador.

Trabalho de Aprendizagem a Distância — Tema: Implementação de Interface Gráfica.
